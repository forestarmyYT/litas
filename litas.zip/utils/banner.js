const banner = `

                  𝐅 𝐎 𝐑 𝐄 𝐒 𝐓 𝐀 𝐑 𝐌 𝐘   
==========================================
🚀 This script is created for **free use**  
❌ Do NOT sell or distribute it for profit!
==========================================

📌 YouTube:  https://youtube.com/@forestarmy
📌 Telegram: https://t.me/forestarmy
📌 GitHub:   https://github.com/itsmesatyavir

💡 Proudly Shared by **itsmesatyavir** 💡
`;

export default banner;

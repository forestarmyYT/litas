import os
import subprocess

# ANSI Color Codes (Avoiding Blue)
RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
MAGENTA = "\033[95m"
CYAN = "\033[96m"
RESET = "\033[0m"

# Permanent Banner
BANNER = f"""{GREEN}
═══════════════════════════════════
{MAGENTA}  𝐅 𝐎 𝐑 𝐄 𝐒 𝐓 𝐀 𝐑 𝐌 𝐘  
{GREEN}═══════════════════════════════════
{RESET}"""

def setup_accounts():
    num_accounts = int(input(f"{YELLOW}🔹 How many accounts do you want to set up?    {RESET}"))

    with open("tokens.txt", "w") as token_file:
        for i in range(num_accounts):
            print(f"\n{CYAN}🔹 Enter details for Account {i+1}:    {RESET}")
            token = input(f"   ➤ {GREEN}Enter token:    {RESET}").strip()
            refresh_token = input(f"   ➤ {GREEN}Enter refresh token:    {RESET}").strip()
            token_file.write(f"{token}|{refresh_token}\n")

    print(f"\n✅ {GREEN}Tokens saved in tokens.txt    {RESET}\n")


def setup_proxies():
    num_proxies = int(input(f"{YELLOW}🔹 How many proxies do you want to add?    {RESET}"))

    with open("proxy.txt", "w") as proxy_file:
        for i in range(num_proxies):
            print(f"\n{CYAN}🔹 Enter details for Proxy {i+1}:    {RESET}")
            proxy = input(f"   ➤ {GREEN}Enter proxy (format: http://username:password@ip:port):    {RESET}").strip()
            proxy_file.write(f"{proxy}\n")

    print(f"\n✅ {GREEN}Proxies saved in proxy.txt    {RESET}\n")


def run_script():
    print(f"\n🚀 {MAGENTA}Running 'node main.js'...    {RESET}\n")
    try:
        subprocess.run(["node", "main.js"], check=True)
    except FileNotFoundError:
        print(f"{RED}❌ Node.js is not installed or main.js is missing!    {RESET}")
    except subprocess.CalledProcessError:
        print(f"{YELLOW}⚠️ Error while running 'node main.js'.    {RESET}")


def main():
    print(BANNER)
    print(f"{YELLOW}\n===== LITAS BOT SCRIPT =====    {RESET}")

    while True:
        print(f"{GREEN}\n===== MENU =====    {RESET}")
        print(f"{MAGENTA}1️⃣  Account Setup    {RESET}")
        print(f"{MAGENTA}2️⃣  Proxy Setup    {RESET}")
        print(f"{MAGENTA}3️⃣  Run Script (💀)    {RESET}")
        print(f"{MAGENTA}4️⃣  Exit    {RESET}")

        choice = input(f"\n🔹 {YELLOW}Select an option (1/2/3/4):    {RESET}").strip()

        if choice == "1":
            setup_accounts()
        elif choice == "2":
            setup_proxies()
        elif choice == "3":
            run_script()
        elif choice == "4":
            print(f"{GREEN}👋 Exiting...    {RESET}")
            break
        else:
            print(f"{RED}❌ Invalid choice. Please enter 1, 2, 3, or 4.    {RESET}")

if __name__ == "__main__":
    main()